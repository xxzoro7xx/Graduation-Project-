    <!-- headers -->
    <nav class="edit navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="home.php">Education World</a>
        <button class="navbar-toggler" type="button" onclick=" headerBo()">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="navbar-collapse " id="hItem">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="admin.php"></i>Profile </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="requestrecived.php"></i>Request </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="ContactUsrecived.php">Complaint <span class="sr-only"></span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="home.php">Log out</a>

                </li>


                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
                </li>
            </ul>

        </div>
    </nav>