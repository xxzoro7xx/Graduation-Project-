<?php

include('connection.php');


session_start();

$postId =$_POST['Remove'];
echo "<script>alert('$postId');</script>";





$sql = "DELETE from post  where Post_id = '$postId'";
$result = mysqli_query($con, $sql);
header("Location: http://localhost/education_world/clubCt.php");
?>