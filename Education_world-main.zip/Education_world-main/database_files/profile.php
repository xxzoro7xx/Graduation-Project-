<?php

include('connection.php');


session_start();

// <?php echo $_SESSION['email']; 
$email = $_SESSION['email'];
$type = $_SESSION['type'];


if($type =="student"){
$FName = "select * from $type where email = '$email'";  
$info= mysqli_query($con, $FName);


        while($row = mysqli_fetch_array($info)){

                $id= $row['S_ID'];
                $FName= $row['FName'];
                $LName = $row['LName'];
                $Major = $row['Major'];
                $club = $row['club_id'];
                

        }

        $_SESSION['S_ID'] = $id;
        $_SESSION['name'] = $FName;


        if($club === "0" or $club == ""){
        $club = "Not a Member";
        }else{
                $club = mysqli_query($con, "select Name from club where Club_ID = '$club'");
                $row = mysqli_fetch_assoc($club);
                $club = $row['Name'];
        }

}else{
        $FName = "select * from $type where Email = '$email'"; 
        $info= mysqli_query($con, $FName);
        while($row = mysqli_fetch_array($info)){

                $id   = $row['T_ID'];
                $FName= $row['FName'];
                $LName = $row['LName'];
                $Major = $row['Major'];
                $phone = $row['Phone'];
                $des = $row['Description'];
                if($des  == ""){
                        $des = "There is no Description...";
                        }else{
            
                                $des = $row['Description'];
                        }

        }

        $_SESSION['S_ID'] = $id;
        $_SESSION['name'] = $FName;
       

}

?>