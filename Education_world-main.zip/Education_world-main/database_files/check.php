<?php

include('connection.php');


session_start();

// <?php echo $_SESSION['email']; 
$email = $_SESSION['email'];
$type = $_SESSION['type'];
$FName = "select * from $type where email = '$email'";  

$info= mysqli_query($con, $FName);

while($row = mysqli_fetch_array($info)){

        $id= $row['club_id'];

        

}



// echo "<script>alert('$id');</script>";
if($id === "0" or $id == ""){
    
}else{
    $sql = "select Name  from club where Club_ID = '$id'";
    $qary = mysqli_query($con, $sql);
    $row3 = mysqli_fetch_array($qary);
    $_SESSION['CName'] = $row3["Name"];
    $_SESSION['club_id'] =$id;
    header("Location: http://localhost/education_world/clubCt.php"); 
}


?>