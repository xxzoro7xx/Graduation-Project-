<?php

include('connection.php');

session_start();
if(isset($_POST['T_ID'])){
$T_ID = $_POST['T_ID'];
}else{
 $T_ID =   $_SESSION['addO'];
}

    $FName = "select * from teacher where T_ID = '$T_ID'"; 
    $info= mysqli_query($con, $FName);
    while($row = mysqli_fetch_array($info)){
            $email =$row['Email'];
            $id   = $row['T_ID'];
            $FName= $row['FName'];
            $LName = $row['LName'];
            $Major = $row['Major'];
            $phone = $row['Phone'];
            $des = $row['Description'];
            
            if($des  == ""){
                $des = "Not a Description...";
                }else{
    
                        $des = $row['Description'];
                }
    }




//  echo "<script>alert('$T_ID');</script>";
// for adding order

 $_SESSION['addO']= $T_ID;



?>