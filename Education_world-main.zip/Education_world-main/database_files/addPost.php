<?php

include('connection.php');


session_start();

// <?php echo $_SESSION['email']; 
$email = $_SESSION['email'];
$type = $_SESSION['type'];
$des = $_POST['des'];  
$club = $_SESSION['club_id'];
$id = $_SESSION['S_ID'];

$date = date('y-m-d H:i:s');
if($des == ""){
        $_SESSION['err1'] = "You did not Write Anyting...";
}else{
mysqli_query($con, "INSERT INTO post (Description ,date , S_ID,Club_ID) VALUES ('{$des}','{$date}', '{$id}', '{$club}')");  
}
header("Location: http://localhost/education_world/clubCt.php");



?>