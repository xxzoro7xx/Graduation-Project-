<?php

include('connection.php');

session_start();
$email = $_SESSION['email'];
$type = $_SESSION['type'];



// echo "<script>alert('$email $type');</script>";
mysqli_query($con,"UPDATE $type SET club_id = null  WHERE Email = '$email';");

header("Location: http://localhost/education_world/club.php");
// session_destroy();






?>