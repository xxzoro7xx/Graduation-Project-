<?php

include('connection.php');


session_destroy();

header("Location: http://localhost/education_world/home.php");



?>