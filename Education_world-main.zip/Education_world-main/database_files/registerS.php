<?php

include('connection.php');
session_start(); 
if (isset($_POST['registerBtn'] )){ 
    $FName = $_POST['first_name']; 
    $LName = $_POST['last_name']; 
    $major = $_POST['major'];
    $passwd = $_POST['user_password']; 
    $passwd_again = $_POST['confirm_password']; 
    $email = $_POST['email'];
    $type = "student";
    if ($email != "" && $passwd != "" && $passwd_again != ""&& $FName != ""&& $LName != ""&& $major != ""){
        // make sure the two passwords match
        if ($passwd === $passwd_again){
            // make sure the password meets the min strength requirements
                $query = mysqli_query($con, "SELECT * FROM $type WHERE Email='{$email}'");
                if (mysqli_num_rows($query) == 0){
          // create and format some variables for the database
                mysqli_query($con, "INSERT INTO $type (S_ID ,Email , Password,Major, FName, LName) VALUES ('{}','{$email}',
                '{$passwd}','{$major}', '{$FName}', '{$LName}')");  
                    $_SESSION['type'] = $type;    
                    $_SESSION['email'] = $email;
                    header("Location: http://localhost/education_world/profile.php");
                }else{
                    $_SESSION['err']='This Email is Taken';
                    header("Location: http://localhost/education_world/registerSTU.php");
                }
        }else{
            $_SESSION['err']='The Passwords do not Match';
                    header("Location: http://localhost/education_world/registerSTU.php");
        }
    }else{
        $_SESSION['err']='Please Fill the Form';
                    header("Location: http://localhost/education_world/registerSTU.php");
    }
}








    // verify the user's account was created
    // $query = mysqli_query($con, "SELECT * FROM sudent WHERE username='{$username}'");
    // if (mysqli_num_rows($query) == 1){
        
    //     /* IF WE ARE HERE THEN THE ACCOUNT WAS CREATED! YAY! */
    //     /* WE WILL SEND EMAIL ACTIVATION CODE HERE LATER */
    
    //     $success = true;
    // }else
    // $error_msg = 'The username <i>'.$username.'</i> is already taken. Please use another.';



?>