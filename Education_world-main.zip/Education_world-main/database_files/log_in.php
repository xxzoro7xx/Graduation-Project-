
<?php

include('connection.php');
// get the post records

session_start();

if (!empty($_POST['type'])) {
    
    

$type = $_POST['type'];
$txtEmail = $_POST['email'];
$txtPassword = $_POST['password'];


// if($type == "student"){

$sql = "select * from $type where Email = '$txtEmail' and password = '$txtPassword';";  
$result = mysqli_query($con, $sql);  
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
$count = mysqli_num_rows($result);  

}else if (empty($_POST['email']) || empty($_POST['password'])) {
    $_SESSION['err'] = '* Please Fill the Email and Password';
    header("Location: http://localhost/education_world/login.php");
    exit;
}else{
    $txtEmail = $_POST['email'];
    $txtPassword = $_POST['password'];
    $sql = "select * from admin where email = '$txtEmail' and password = '$txtPassword'";  
    $result = mysqli_query($con, $sql); 
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);   
    $count1 = mysqli_num_rows($result);
    
    if($count1== 1){
        $_SESSION['type'] = $type;
        $_SESSION['email'] = $txtEmail;
        header("Location: http://localhost/education_world/admin.php");
        exit;
    }else{
    $_SESSION['err'] = '* Please Select a Type';
    header("Location: http://localhost/education_world/login.php");
    exit;
    }
}
if($count == 1){  
    $_SESSION['type'] = $type;
    $_SESSION['email'] = $txtEmail;
    
    if($type == "student"){
        $sql = "select S_ID from student where email = '$txtEmail'";
        $result = mysqli_query($con, $sql);
        $row2 = mysqli_fetch_array($result);
        $_SESSION['S_ID'] = $row2["S_ID"]; 
        
    header("Location: http://localhost/education_world/explore.php"); 
    }else{

        $sql = "select state from teacher where email = '$txtEmail'";
        $result = mysqli_query($con, $sql);
        $row2 = mysqli_fetch_array($result);
        $state = $row2["state"];  
        if($state == "2"){
            $sql = "select T_ID from teacher where email = '$txtEmail'";
            $result = mysqli_query($con, $sql);
            $row2 = mysqli_fetch_array($result);
            $_SESSION['IDT'] = $row2["T_ID"];  
        header("Location: http://localhost/education_world/profileteacher.php");
        }else if($state == "3"){
            $_SESSION['err'] = 'Your Register Declined';
            header("Location: http://localhost/education_world/login.php");
            exit;
            }
            else{
            $_SESSION['err'] = 'Still Not Approved';
            header("Location: http://localhost/education_world/login.php");
            exit;
             }
    }
}  
else{ 
    $_SESSION['err'] = '* Email or Password Incorrect';
    header("Location: http://localhost/education_world/login.php");
    
}





?>



