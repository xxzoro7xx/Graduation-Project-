<?php

include('connection.php');

session_start();
$email = $_SESSION['email'];
$club_id = $_POST['the_name'];
$type = $_SESSION['type'];

mysqli_query($con,"UPDATE $type SET club_id = '$club_id'  WHERE email = '$email';");
$_SESSION['club_id'] =$club_id; 
$sql = "select Name  from club where Club_ID = '$club_id'";
$qary = mysqli_query($con, $sql);
$row3 = mysqli_fetch_array($qary);
$_SESSION['CName'] = $row3["Name"];
header("Location: http://localhost/education_world/clubCt.php");
// session_destroy();






?>