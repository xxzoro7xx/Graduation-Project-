<?php

session_start();
include('connection.php');




// <?php echo $_SESSION['email']; 

$idS = $_SESSION['S_ID'];
$idT = $_SESSION['addO'];
$des = $_POST['des'];
$price =$_POST['price'];


if($des == "" ){
        $_SESSION['err1'] = "You did not Write Anyting...";
}else{
    
mysqli_query($con, "INSERT INTO porder(T_ID ,S_ID ,price ,description) VALUES ('{$idT}','{$idS}','{$price}','{$des}')");

header("Location: http://localhost/education_world/notification.php");

}



?>


