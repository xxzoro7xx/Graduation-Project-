<?php

include('connection.php');


// <?php echo $_SESSION['email']; 
$idC = $_SESSION['club_id'];

// echo "<script>alert('$id');</script>";
$sql = "select COUNT(*) from post where Club_ID = '$idC'";
$info = mysqli_query($con, $sql);
$row = mysqli_fetch_array($info);
$total = $row[0];


$sql = "select * from post where Club_ID = '$idC' ORDER BY date DESC;";
$info = mysqli_query($con, $sql);

if($total == 0){
    echo <<<EOL
<div class="chat card p-3" >
    <div class=" d-flex justify-content-between align-items-center">
        <div class="user d-flex flex-row align-items-center ">
        <img src="https://i.imgur.com/hczKIze.jpg" width="30" class="user-img rounded-circle mr-2"> <span><small
                class="font-weight-bold text-primary ">Edcucation World</small>
                <br> <small class=" font-weight-bold">There is No post Start One</small></span>
        </div> 
    </div>
    <div class="action d-flex justify-content-between mt-2 align-items-center">
    <div class="reply px-4"> <small></small> <span class=""></span> <small></small></div>
    <div class="time" ><small >Today</small></div>

    </div>
</div>     
EOL;
}

for (;$total >0 ; $total--){
while($row = mysqli_fetch_array($info)){

    $id = $row['S_ID'];
    $idC= $row['Club_ID'];
    $des = $row['Description'];
    $date = $row['date'];
    $postId= $row["Post_Id"]; 


    $sql = "select FName  from student where S_ID = '$id'";
    $result = mysqli_query($con, $sql);
    $row2 = mysqli_fetch_array($result);
    $name = $row2["FName"];   
    $todayD = date('Y-m-d' );
    $date = substr($date, 0, -9);
    $equal = strcmp($date, $todayD);
     
    if($equal === 0){
        $date = "Today";
    }



if($id == $_SESSION['S_ID']){

echo <<<EOL
<div class="chat card p-3" >
    <div class=" d-flex justify-content-between align-items-center">
        <div class="user d-flex flex-row align-items-center ">
        <img src="https://i.imgur.com/hczKIze.jpg" width="30" class="user-img rounded-circle mr-2"> <span><small
                class="font-weight-bold text-primary ">$name</small>
                <br> <small class=" font-weight-bold">$des</small></span>
        </div> 
    </div>
    <div class="action d-flex justify-content-between mt-2 align-items-center">
    <div class="reply px-4"> <form action='database_files/deleteP.php' method="post"> <button type="submit" name="Remove" value='$postId'>Remove</button></form> <span class=""></span> <small></small></div>
    <div class="time" ><small >$date</small></div>

    </div>
</div>     
EOL;
}else {
    echo <<<EOL
    <div class="chat card p-3" >
        <div class=" d-flex justify-content-between align-items-center">
            <div class="user d-flex flex-row align-items-center ">
            <img src="https://i.imgur.com/hczKIze.jpg" width="30" class="user-img rounded-circle mr-2"> <span><small
                    class="font-weight-bold text-primary ">$name</small>
                    <br> <small class=" font-weight-bold">$des</small></span>
            </div> 
        </div>
        <div class="action d-flex justify-content-between mt-2 align-items-center">
        <div class="reply px-4"> <small></small> <span class=""></span> <small></small></div>
        <div class="time" ><small >$date</small></div>
    
        </div>
    </div>     
    EOL;

}
}
} 


?>