<?php

include('connection.php');


session_start();





$oid= $_SESSION['idO'];


mysqli_query($con,"UPDATE porder SET state = '4'  WHERE o_id = '$oid';");
// header("Location: http://localhost/education_world/notification.php");
        

?>