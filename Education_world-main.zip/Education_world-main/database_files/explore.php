

<?php

include('connection.php');
// get the post records


$sql = "select COUNT(*) from teacher ";
$result = mysqli_query($con, $sql);
$row2 = mysqli_fetch_array($result);
$total = $row2[0];






$FName = "select * from teacher";  

$info= mysqli_query($con, $FName);
echo <<< EOL
<script>
var data = [];
EOL;

for (;$total >0 ; $total--){
while($row = mysqli_fetch_array($info)){

    $id   = $row['T_ID'];
    $FName= $row['FName'];
    $LName = $row['LName'];
    $Major = $row['Major'];
    $phone = $row['Phone'];
    $des = $row['Description'];
    $state = $row['state'];


    if($state == '2'){
     

    echo <<< EOL
    data.push({
    "name": '$FName',
    "Major": '$Major',
    "subject": "not yt",
    "price": "$20",
    "image": "https://bootdey.com/img/Content/avatar/avatar2.png",
    "T_ID": '$id'
    
    });

    EOL;
  }

}

}




echo <<< EOL
var products = "",
  name = "",
  Majors = "",
  subjects = "";

for (var i = 0; i < data.length; i++) {
  var name = data[i].name,
    Major = data[i].Major,
    subject = data[i].subject,
    price = data[i].price,
    rawPrice = price.replace("$", ""),
    rawPrice = parseInt(rawPrice.replace(",", "")),
    image = data[i].image;
    T_ID = data[i].T_ID,

  //create product cards
  products += "<div class='col-sm-4 product' data-name='" + name + "' data-Major='" + Major + "' data-subject='" + subject + "' data-price='" + rawPrice + "'><button type='Submit' form='form1' name='T_ID' value='" + T_ID + "'><div class='product-inner text-center'><img src='" + image + "'><br />name: " +  name  + "<br />Major: " + Major + "<br />subject: " + subject + "<br />Price: " + price + "</div></button></div>";
  //create dropdown of name
  if (name.indexOf("<option value='" + name + "'>" + name + "</option>") == -1) {
    name += "<option value='" + name + "'>" + name + "</option>";
  }

  //create dropdown of Majors
  if (Majors.indexOf("<option value='" + Major + "'>" + Major + "</option>") == -1) {
    Majors += "<option value='" + Major + "'>" + Major + "</option>";
  }

  //create dropdown of subjects
  if (subjects.indexOf("<option value='" + subject + "'>" + subject + "</option>") == -1) {
    subjects += "<option value='" + subject + "'>" + subject + "</option>";
  }
}

$("#products").html(products);
$(".filter-name").append(name);
$(".filter-Major").append(Majors);
$(".filter-subject").append(subjects);

var filtersObject = {};

//on filter change
$(".filter").on("change", function() {
  var filterName = $(this).data("filter"),
    filterVal = $(this).val();

  if (filterVal == "") {
    delete filtersObject[filterName];
  } else {
    filtersObject[filterName] = filterVal;
  }

  var filters = "";

  for (var key in filtersObject) {
    if (filtersObject.hasOwnProperty(key)) {
      filters += "[data-" + key + "='" + filtersObject[key] + "']";
    }
  }

  if (filters == "") {
    $(".product").show();
  } else {
    $(".product").hide();
    $(".product").hide().filter(filters).show();
  }
});

//on search form submit
$("#search-form").submit(function(e) {
  e.preventDefault();
  var query = $("#search-form input").val().toLowerCase();

  $(".product").hide();
  $(".product").each(function() {
    var name = $(this).data("name").toLowerCase(),
      Major = $(this).data("Major").toLowerCase(),
      subject = $(this).data("subject").toLowerCase();

    if (name.indexOf(query) > -1 || Major.indexOf(query) > -1 || subject.indexOf(query) > -1) {
      $(this).show();
    }
  });
});
</script>
EOL;



?>