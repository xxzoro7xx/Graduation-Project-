<?php
include('connection.php');

// <?php echo $_SESSION['email']; 
$id = $_SESSION['S_ID'];

// echo "<script>alert('$id');</script>";
$sql = "select COUNT(*) from porder where S_ID = '$id'";
$info = mysqli_query($con, $sql);
$row = mysqli_fetch_array($info);
$total = $row[0];


$sql = "select * from student where S_ID = '$id'";
$result = mysqli_query($con, $sql);
$row2 = mysqli_fetch_array($result);
$SFName = $row2["FName"]; 
$SLName = $row2["LName"]; 


$sql = "select * from porder where S_ID = '$id'";
$info = mysqli_query($con, $sql);

// if there is no teacher not active 
if($total == 0){
    echo <<<EOL
    <div class="p-3 d-flex align-items-center osahan-post-header request">
    <div class="dropdown-list-image mr-3"></div>
    <div class="font-weight-bold mr-3">
        <div>
            <span class="font-weight-normal">There No orders</span> 
            <div class="small text-success"><i class="fa fa-check-circle"></i> Thank you</div>
        </div>
    </div>
</div>
EOL;
}else
for (;$total >0 ; $total--){
while($row = mysqli_fetch_array($info)){

    $idT = $row['T_ID'];
    $oState = $row["state"]; 
    $OID = $row["o_id"];
    
    $sql = "select * from Teacher where T_ID = '$idT'";
    $result = mysqli_query($con, $sql);
    $row2 = mysqli_fetch_array($result);
    $TFName = $row2["FName"]; 
    $TLName = $row2["LName"]; 
    $phone = $row2["Phone"]; 

if($oState == 1){
echo <<<EOL
<div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
<div class="dropdown-list-image mr-3">
    <img class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar1.png"
        alt="" />
</div>
<div class="font-weight-bold mr-3">
    <div class="mb-2"><span >$SFName $SLName </span><br>
    <span class="font-weight-normal"> Your Order for $TFName $TLName Have Been Placed.</span></div>
            <div class="small text-success"><i class="fa fa-check-circle"></i> Waiting For Approval</div>
                </div>
        </div>
EOL;
}
if($oState == 2){
    echo <<<EOL
    <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
    <div class="dropdown-list-image mr-3">
        <img class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar1.png"
            alt="" />
    </div>
    <div class="font-weight-bold mr-3">
        <div class="mb-2"><span >$SFName $SLName </span><br>
        <span class="font-weight-normal"> Your Order for $TFName $TLName Approved</span></div>
            <div>
                <form action="payment.php" method="post" target="_blank" style="display: inline;">
                <button type="Submit" name='idO' value="$OID" class="btn btn-outline-success btn-sm pl-4 pr-4"id="Accept">Pay</button>
                </form>
                <form action="database_files/cancelO.php" method="post" style="display: inline;" >
                <button type="Submit" name='state' value="$OID" class="btn btn-outline-success btn-sm pl-4 pr-4" id="declined">Cancel</button>
                </form>
                
            </div>
                <div class="small text-success"><i class="fa fa-check-circle"></i> Aproved Please pay</div>
                </div>
            </div> 
    EOL;
    }
    if($oState == 3){
        echo <<<EOL
                        
                         <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                            <div
                                class="dropdown-list-image mr-3 d-flex align-items-center bg-success justify-content-center rounded-circle text-white">
                                M</div>
                            <div class="font-weight-bold mr-3">
                                <div class="text-truncate">$SFName $SLName</div>
                                <div class="small">Your request for $TFName $TLName have been Declined
                                <br><span id="checked">Request Declined </span>
                                </div>
                            </div>
                        </div>

        EOL;
        }

        if($oState == 4){
            echo <<<EOL
                            
                             <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                                <div
                                    class="dropdown-list-image mr-3 d-flex align-items-center bg-success justify-content-center rounded-circle text-white">
                                    M</div>
                                <div class="font-weight-bold mr-3">
                                    <div class="text-truncate">$SFName $SLName</div>
                                    <div class="small">Your request for $TFName $TLName have been complete.<br><span>here is the communication link <a href="https://wa.me/$phone" target="_blank">:https://wa.me/$phone </a></span>
                                    <br><div class="small text-success"><i class="fa fa-check-circle"></i> Complete</div>
                                    </div>
                                </div>
                                </div>
                       
            
            EOL;
            }
} 

}

?>