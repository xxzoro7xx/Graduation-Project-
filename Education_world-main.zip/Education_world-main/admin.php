<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>

<?php include 'head.php'; ?>

<body>


  <?php include 'headeradmin.php'; ?>
<?php include 'admin/ProfileA.php'?>

  <div class=" bodyT">

    <!--body-->

    <div class="container bootstrap snippets bootdey " style="min-height: 500px;">
      <div class="row" >
        <div class="profile-nav col-md-3" >
          <div class="panel" >
            <div class="user-heading round">
              <a href="#">
                <img src="https://www.w3schools.com/w3images/avatar1.png" alt="">
              </a>
              <h1>admin</h1>
              <p><?php echo $email?></p>
            </div>
          </div>
        </div>
        <div class="profile-info col-md-9">
          <div class="panel">


          </div>
          <div class="panel">
            <div class="bio-graph-heading">
              <p>Admin panel </p>
            </div>
            <div class="panel-body bio-graph-info">

              <div class="row">
                <div class="bio-row">
                  <p><span> Name </span>: <?php echo $name?></p>
                </div>
                <div class="bio-row">
                  <p><span>Email </span>: <?php echo $email?></p>
                </div>
                <div class="bio-row">
                  <p><span>Mobile </span>: <?php echo $phone?></p>
                </div>
                
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>

  </div>



<!--  -->
</body>

</html>