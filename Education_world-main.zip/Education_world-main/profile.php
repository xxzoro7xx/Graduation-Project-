<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<meta charset="utf-8">
<title>user profile bio </title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<?php include 'head.php'; ?>

<body>

  <?php include 'database_files/profile.php'; ?>

  <?php include 'headerS.php'; ?>
  <div class="bodyPro">

    <!--body-->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <div class="container bootstrap snippets bootdey">
      <div class="row">
        <div class="profile-nav col-md-3">
          <div class="panel">
            <div class="user-heading round">
              <a href="#">
                <img src="https://www.w3schools.com/w3images/avatar1.png" alt="">
              </a>
              <h1>Student</h1>
              <p><?php echo $_SESSION['email']; ?></p>
              <a href="#" class="btn btn-sm btn-info mb-2">Edit Profile</a>

            </div>

              <!-- <ul class="nav nav-pills nav-stacked">
              <li class="active"><a href="#"> <i class="fa fa-user"></i> Profile</a></li>
              <li><a href="#"> <i class="fa fa-calendar"></i> Notifications <span class="label label-warning pull-right r-activity">9</span></a></li>
              <li><a href="club.php"> <i class="fa fa-edit"></i>Student club</a></li>
              <li><a href=""> <i class="fa fa-edit"></i> student's review</a></li>
              <li><a href="explore.php"> <i class="fa fa-edit"></i> Explore</a></li>
              <li><a href="FindingTeacher.php"> <i class="fa fa-edit"></i> search for teacher</a></li>

            </ul>-->
          </div>
        </div>
        <div class="profile-info col-md-9">
          <!-- <div class="panel">
            <form>
              <textarea placeholder="Whats in your mind today?" rows="2" class="form-control input-lg p-text-area"></textarea>
            </form>
            <footer class="panel-footer">
              <button class="btn btn-warning pull-right">Post</button>
              <ul class="nav nav-pills">
                <li>
                  <a href="#"><i class="fa fa-map-marker"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa fa-camera"></i></a>
                </li>
                <li>
                  <a href="#"><i class=" fa fa-film"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa fa-microphone"></i></a>
                </li>
              </ul>
            </footer>
          </div> -->
          <div class="panel">
            <div class="bio-graph-heading">

            </div> 
            <div class="panel-body bio-graph-info">
              <h1>My Information</h1>
              <div class="row">
                <div class="bio-row">
                  <p><span>First Name </span>: <?php echo $FName ?></p>
                </div>
                <div class="bio-row">
                  <p><span>Last Name </span>: <?php echo $LName ?></p>
                </div>
                <div class="bio-row">
                  <p><span>City </span>: Jubail</p>
                </div>
                <div class="bio-row">
                  <p><span>Club</span>: <?php echo $club ?></p>
                </div>
                <div class="bio-row">
                  <p><span>Major </span>: <?php echo $Major ?></p>
                </div>
                <div class="bio-row">
                  <p><span>Email </span>: <?php echo $_SESSION['email']; ?></p>
                </div>
                <!-- <div class="bio-row">
                  <p><span>Mobile </span>: +966*********</p>
                </div> -->
                <div class="bio-row">
                  <p><span> </span></p>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div class="row">
              <div class="col-md-6">
                <div class="panel">
                  <div class="panel-body">
                    <div class="bio-chart">
                      <div style="display:inline;width:100px;height:100px;"><canvas width="100" height="100px"></canvas><input class="knob" data-width="100" data-height="100" data-displayprevious="true" data-thickness=".2" value="20" data-fgcolor="#e06b7d" data-bgcolor="#e8e8e8" style="width: 54px; height: 33px; position: absolute; vertical-align: middle; margin-top: 33px; margin-left: -77px; border: 0px; font-weight: bold; font-style: normal; font-variant: normal; font-stretch: normal; font-size: 20px; line-height: normal; font-family: Arial; text-align: center; color: rgb(224, 107, 125); padding: 0px; -webkit-appearance: none; background: none;"></div>
                    </div>
                    <div class="bio-desk">
                      <h4 class="red">posts </h4>
                      <p></p>
                      <p></p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="panel">
                  <div class="panel-body">
                    <div class="bio-chart">
                      <div style="display:inline;width:100px;height:100px;"><canvas width="100" height="100px"></canvas><input class="knob" data-width="100" data-height="100" data-displayprevious="true" data-thickness=".2" value="12" data-fgcolor="#4CC5CD" data-bgcolor="#e8e8e8" style="width: 54px; height: 33px; position: absolute; vertical-align: middle; margin-top: 33px; margin-left: -77px; border: 0px; font-weight: bold; font-style: normal; font-variant: normal; font-stretch: normal; font-size: 20px; line-height: normal; font-family: Arial; text-align: center; color: rgb(76, 197, 205); padding: 0px; -webkit-appearance: none; background: none;"></div>
                    </div>
                    <div class="bio-desk">
                      <h4 class="terques">Review </h4>
                      <p></p>
                      <p></p>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <script type="text/javascript"></script>

  <?php include 'footerS.php'; ?>

</body>

</html>