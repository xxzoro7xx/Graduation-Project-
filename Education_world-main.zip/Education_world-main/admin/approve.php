<?php

include('connection.php');

session_start();

$T_id = $_POST['the_name'];

// approve 
mysqli_query($con,"UPDATE teacher SET state = '2'  WHERE T_ID = '$T_id';");

header("Location: http://localhost/education_world/requestrecived.php");





?>