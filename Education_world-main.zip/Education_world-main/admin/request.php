<?php

include('connection.php');




// <?php echo $_SESSION['email']; 


// echo "<script>alert('$id');</script>";
$sql = "select COUNT(*) from teacher where state = '1'";
$info = mysqli_query($con, $sql);
$row = mysqli_fetch_array($info);
$total = $row[0];





$sql = "select * from teacher where state = '1'";
$info = mysqli_query($con, $sql);

// if there is no teacher not active 
if($total == 0){
    echo <<<EOL
    <div class="p-3 d-flex align-items-center osahan-post-header request">
    <div class="dropdown-list-image mr-3"></div>
    <div class="font-weight-bold mr-3">
        <div>
            <span class="font-weight-normal">There No Request Need to be check</span> 
            <div class="small text-success"><i class="fa fa-check-circle"></i> Thank you</div>
        </div>
    </div>
</div>

EOL;
}
// else
for (;$total >0 ; $total--){
while($row = mysqli_fetch_array($info)){

    $id = $row['T_ID'];
    $email= $row['Email'];
    $FName = $row['FName'];
    $LName = $row['LName'];
    $file = $row['Documents'];
    $phone= $row["Phone"]; 






echo <<<EOL
<div class="box-body p-0 ">
                        <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                            <div class="dropdown-list-image mr-3 d-flex align-items-center bg-danger justify-content-center rounded-circle text-white"
                                >DRM</div>
                            <div class="font-weight-bold mr-3">
                                <div class="text-truncate">$FName $LName </div>
                                <div class="small"><span style="font-weight: bold">Email:</span> $email  <span style="font-weight: bold">phone:</span> $phone 
                                </div>
                                <div class="p-2">
                                    <form action="admin/approve.php" method="post" style="display:inline;">
                                    <button type="submit" name="the_name" value="$id" class="btn btn-outline-success btn-sm pl-4 pr-4">Accept</button>
                               </form><form action="admin/cancel.php" method="post" style="display:inline;">
                                    <button type="submit" name="id" value="$id" class="btn btn-outline-success btn-sm pl-4 pr-4"id="declined">Decline</button>
                                    </form>
                                </div>
                            </div>
                            <span class="ml-auto mb-auto POspan">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-light btn-sm rounded" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical"></i>edit
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right" >
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-delete"></i>
                                            Delete</button>
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-close"></i> Turn
                                            Off</button>
                                    </div>
                                </div>
                                <br />
                                <div class="text-right text-muted pt-1">1d</div>
                            </span>
                        </div>  
                    </div> 
EOL;

} 
}

?>