<?php
session_start();
include('connection.php');

$nameC = $_POST['name'];
$email = $_POST['email'];
$des = $_POST['des'];




mysqli_query($con, "INSERT INTO complaint (Name ,email , description) VALUES ('{$nameC}','{$email}', '{$des}')");  
$_SESSION['err2'] = "Send Successful";

header("Location: http://localhost/education_world/ContactUsS.php");






?>