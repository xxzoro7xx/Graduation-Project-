<?php

include('connection.php');


session_start();
$id = $_POST['id'];


    mysqli_query($con,"UPDATE teacher SET state = '3'  WHERE T_ID = '$id';");
    header("Location: http://localhost/education_world/requestrecived.php");

?>