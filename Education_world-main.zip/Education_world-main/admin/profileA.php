<?php

include('connection.php');


session_start();

// <?php echo $_SESSION['email']; 
$email = $_SESSION['email'];
$type = "admin";



        $FName = "select * from $type where Email = '$email'"; 
        $info= mysqli_query($con, $FName);
        while($row = mysqli_fetch_array($info)){

                $id   = $row['ID'];
                $name= $row['Name'];
                $email = $row['Email'];
                $phone = $row['Phone'];
        }




?>