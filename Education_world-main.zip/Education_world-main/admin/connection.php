
<?php
$con = mysqli_connect('localhost', 'root', '','education_world');
if(!$con){
    die("connection error: " . mysql_error());

}


?>
