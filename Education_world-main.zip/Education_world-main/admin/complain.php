<?php

include('connection.php');




// <?php echo $_SESSION['email']; 


// echo "<script>alert('$id');</script>";
$sql = "select COUNT(*) from complaint ";
$info = mysqli_query($con, $sql);
$row = mysqli_fetch_array($info);
$total = $row[0];



$sql = "select * from complaint";
$info = mysqli_query($con, $sql);

// if there is no teacher not active 
if($total == 0){
    echo <<<EOL
        <div class="container shadow">
        <h6 class="preview-subject"></h6>
        <p class="text-muted" style="text-align: center;">There is no Complaint</p>
        <span class="text-muted text-small time-right"></span>
        </div>

EOL;
}else
for (;$total >0 ; $total--){
while($row = mysqli_fetch_array($info)){

    $name = $row['Name'];
    $email = $row["email"]; 
    $des = $row["description"];
    // $date 

echo <<<EOL
<div class="p-3 d-flex align-items-center border-bottom osahan-post-header request shadow">
<div class="dropdown-list-image mr-3">
    <img class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar1.png"
        alt="" />
</div>
<div class="font-weight-bold mr-3" style="margin-bottom:10px;">
    <div class="mb-2"><span >$name $email  </span><br>
    <span class="font-weight-normal"> $des</span><br></div>
           </div>
        </div>


EOL;
} 

}

?>