<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>


<link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.css"
    integrity="sha256-NAxhqDvtY0l4xn+YVa6WjAcmd94NNftt" />
<?php  include 'head.php';?>

<body>
<?php session_start();
include('database_files/connection.php');
$email = $_SESSION['email'];
$sql = "select FName from student where email = '$email'";
$result = mysqli_query($con, $sql);
$row2 = mysqli_fetch_array($result);
$Name = $row2["FName"]; 

?>

    <?php include 'headerS.php';?>

    <div class="container Rqbody" style=" min-height: 500px;">
        <div class="row">
            <div class="col-lg-3 left">
                <div class="box shadow-sm mb-3 rounded bg-white ads-box text-center">
                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="img-fluid"
                        alt="Responsive image" />
                    <div class="p-3 border-bottom">
                        <h6 class="font-weight-bold text-dark">Notifications</h6>
                        <p class="mb-0 text-muted">You’re all caught up! Check back later for new notifications</p>
                    </div>
                    <div class="p-3">                   
                        <button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4">Accept</button>
                        <button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4">Decline</button>
                    </div>
                </div>
                <div class="box mb-3 shadow-sm rounded bg-white profile-box text-center" style="background-color: aqua;">
                    <div class="p-5">
                        <img src="https://bootdey.com/img/Content/avatar/avatar6.png" class="img-fluid"
                            alt="Responsive image" />
                    </div>
                    <div class="p-3 border-top border-bottom">
                        <h5 class="font-weight-bold text-dark mb-1 mt-0"><?php echo  $Name  ?></h5>
                        <p class="mb-0 text-muted"><?php echo  $_SESSION['email']  ?></p>
                    </div>
                    <div class=" row box justify-content-center" >
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-9 right">

                <div class="box shadow-sm rounded bg-white mb-3">
                    <div class="box-title border-bottom p-3">
                        <h6 class="m-0">Requests</h6>
                    </div>


                        <?php include "database_files/notification.php";?>

                        




                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <?php include 'footerS.php';?>

</body>

</html>