<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>

<?php include 'head.php'; ?>
<link rel="stylesheet" href="Gcss.css">

<body>


  <?php include 'header.php'; ?>


  <!--body-->


  <div class="container">

    <form class="well form-horizontal" action="database_files/registerS.php" method="post" id="contact_form">
      <fieldset>
      <?php session_start(); ?>
        <!-- Form Name -->
        <legend>
          <center>
            <h2><b>Registration Form</b></h2>
          </center>
        </legend><br>

        <!-- Text input-->

        <div class="form-group">
          <label class="col-md-4 control-label">First Name</label>
          <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input name="first_name" placeholder="First Name" class="form-control" type="text">
            </div>
          </div>
        </div>

        <!-- Text input-->

        <div class="form-group">
          <label class="col-md-4 control-label">Last Name</label>
          <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input name="last_name" placeholder="Last Name" class="form-control" type="text">
            </div>
          </div>
        </div>

        <div class="form-group">
          <label for="major" class="col-md-4 control-label">Majors</label>
          <div class="col-md-4 selectContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
              <select name="major" class="form-control selectpicker" id="major">
                <option value="">Select your Major</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Business Administration">Business Administration</option>
                <option value="Chemical Engineering">Chemical Engineering</option>
                <option value="electrical engineering">electrical engineering</option>
                <option value="Mechanical Engineering">Mechanical Engineering</option>
                <option value="Civil Engineering">Civil Engineering</option>
                <option value="ARCHITECTURE">ARCHITECTURE</option>
                <option value="HEALTH SCIENCES">HEALTH SCIENCES</option>
                <option value="SOCIAL SCIENCES & LAW">SOCIAL SCIENCES & LAW </option>
              </select>
            </div>
          </div>
        </div>

        <!-- Text input-->

        <!-- <div class="form-group">
          <label class="col-md-4 control-label">Username</label>
          <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input name="user_name" placeholder="Username" class="form-control" type="text">
            </div>
          </div>
        </div> -->

        <!-- Text input-->

        <div class="form-group">
          <label class="col-md-4 control-label">Password</label>
          <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input name="user_password" minlength="8" placeholder="Password" class="form-control" type="password">
            </div>
          </div>
        </div>

        <!-- Text input-->

        <div class="form-group">
          <label class="col-md-4 control-label">Confirm Password</label>
          <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input name="confirm_password" minlength="8" placeholder="Confirm Password" class="form-control" type="password">
            </div>
          </div>
        </div>

        <!-- Text input-->
        <div class="form-group">
          <label for="email" class="col-md-4 control-label form-label" >E-Mail</label>
          <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
              <input name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2, 4}$" placeholder="email@example.com" class="form-control"  type="email">
            </div>
          </div>
        </div>


        <!-- Text input-->

        <!-- <div class="form-group">
          <label class="col-md-4 control-label">Phone number</label>
          <div class="col-md-4 inputGroupContainer">
            <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
              <input name="phone" placeholder="(+966)" class="form-control" type="text">
            </div>
          </div>
        </div> -->

        <!-- Select Basic -->
        <span class="errorR"> <?php if (isset($_SESSION['err'])){echo $_SESSION['err']; unset($_SESSION['err']);}?></span>
        <!-- Success message -->
        <div class="alert alert-success" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Success!.</div>

        <!-- Button -->
        <div class="form-group">
          <label class="col-md-4 control-label"></label>
          <div class="col-md-4"><br>
            
            <button type="submit" class="btn btn-warning" name="registerBtn">SUBMIT <span class="glyphicon glyphicon-send"></span></button>
          </div>
        </div>

      </fieldset>
    </form>
  </div>
  </div><!-- /.container -->



</body>

<script>
  $(document).ready(function() {
    $("#contact_form")
      .bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
          valid: "glyphicon glyphicon-ok",
          invalid: "glyphicon glyphicon-remove",
          validating: "glyphicon glyphicon-refresh"
        },
        fields: {
          first_name: {
            validators: {
              stringLength: {
                min: 2
              },
              notEmpty: {
                message: "Please enter your First Name"
              }
            }
          },
          last_name: {
            validators: {
              stringLength: {
                min: 2
              },
              notEmpty: {
                message: "Please enter your Last Name"
              }
            }
          },
          user_name: {
            validators: {
              stringLength: {
                min: 8
              },
              notEmpty: {
                message: "Please enter your Username"
              }
            }
          },
          user_password: {
            validators: {
              stringLength: {
                min: 8
              },
              notEmpty: {
                message: "Please enter your Password"
              }
            }
          },
          confirm_password: {
            validators: {
              stringLength: {
                min: 8
              },
              notEmpty: {
                message: "Please confirm your Password"
              }
            }
          },
          email: {
            validators: {
              notEmpty: {
                message: "Please enter your Email Address"
              },
              emailAddress: {
                message: "Please enter a valid Email Address"
              }
            }
          },
          contact_no: {
            validators: {
              stringLength: {
                min: 12,
                max: 12,
                notEmpty: {
                  message: "Please enter your Contact No."
                }
              }
            },
            department: {
              validators: {
                notEmpty: {
                  message: "Please select your Department/Office"
                }
              }
            }
          }
        }
      })
      .on("success.form.bv", function(e) {
        $("#success_message").slideDown({
          opacity: "show"
        }, "slow"); // Do something ...
        $("#contact_form").data("bootstrapValidator").resetForm();

        // Prevent form submission
        e.preventDefault();

        // Get the form instance
        var $form = $(e.target);

        // Get the BootstrapValidator instance
        var bv = $form.data("bootstrapValidator");

        // Use Ajax to submit form data
        $.post(
          $form.attr("action"),
          $form.serialize(),
          function(result) {
            console.log(result);
          },
          "json"
        );
      });
  });
</script>

</html>