<footer>

   <div class="navbar-expand-lg" id="footinfo">
      <div><a href="AboutUsT.php"> About Us</a><br>
      </div><!-- the id is arrang-->
      <div><a href="ContactUsT.php"> Contcat Us</a></div>
   </div>




</footer>