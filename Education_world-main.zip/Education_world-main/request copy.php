<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>


<link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.css"
    integrity="sha256-NAxhqDvtY0l4xn+YVa6WjAcmd94NNftt" />
<?php  include 'head.php';?>

<body>


    <?php include 'headerT.php';?>

    <div class="container Rqbody">
        <div class="row">
            <div class="col-lg-3 left">
                <div class="box shadow-sm mb-3 rounded bg-white ads-box text-center">
                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="img-fluid"
                        alt="Responsive image" />
                    <div class="p-3 border-bottom">
                        <h6 class="font-weight-bold text-dark">Notifications</h6>
                        <p class="mb-0 text-muted">You’re all caught up! Check back later for new notifications</p>
                    </div>
                    <div class="p-3">                   
                        <button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4">Accept</button>
                        <button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4">Decline</button>
                    </div>
                </div>
                <div class="box mb-3 shadow-sm rounded bg-white profile-box text-center" style="background-color: aqua;">
                    <div class="p-5">
                        <img src="https://bootdey.com/img/Content/avatar/avatar6.png" class="img-fluid"
                            alt="Responsive image" />
                    </div>
                    <div class="p-3 border-top border-bottom">
                        <h5 class="font-weight-bold text-dark mb-1 mt-0">Envato</h5>
                        <p class="mb-0 text-muted">Melbourne, AU</p>
                    </div>
                    <div class=" row box justify-content-center" >
                        <div class="calendar col-lg-5 col-md-12   col-sm-10">
                            <!-- <div class="calendar__picture">
                              <h2>18, Sunday</h2>
                              <h3>November</h3>
                            </div> -->
                            <div class="calendar__date">
                              <div class="calendar__day">M</div>
                              <div class="calendar__day">T</div>
                              <div class="calendar__day">W</div>
                              <div class="calendar__day">T</div>
                              <div class="calendar__day">F</div>
                              <div class="calendar__day">S</div>
                              <div class="calendar__day ">S</div>
                              <div class="calendar__day"></div>
                              <div class="calendar__number"></div>
                              <div class="calendar__number"></div>
                              <div class="calendar__number">1</div>
                              <div class="calendar__number">2</div>
                              <div class="calendar__number">3</div>
                              <div class="calendar__number">4</div>
                              <div class="calendar__number">5</div>
                              <div class="calendar__number">6</div>
                              <div class="calendar__number">7</div>
                              <div class="calendar__number">8</div>
                              <div class="calendar__number">9</div>
                              <div class="calendar__number">10</div>
                              <div class="calendar__number">11</div>
                              <div class="calendar__number">12</div>
                              <div class="calendar__number">13</div>
                              <div class="calendar__number">14</div>
                              <div class="calendar__number">15</div>
                              <div class="calendar__number">16</div>
                              <div class="calendar__number">17</div>
                              <div class="calendar__number calendar__number--current">18</div>
                              <div class="calendar__number">19</div>
                              <div class="calendar__number">20</div>
                              <div class="calendar__number">21</div>
                              <div class="calendar__number">22</div>
                              <div class="calendar__number">23</div>
                              <div class="calendar__number">24</div>
                              <div class="calendar__number">25</div>
                              <div class="calendar__number">26</div>
                              <div class="calendar__number">27</div>
                              <div class="calendar__number">28</div>
                              <div class="calendar__number">29</div>
                              <div class="calendar__number">30</div>
                            </div>
                          </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 right">

                <div class="box shadow-sm rounded bg-white mb-3">
                    <div class="box-title border-bottom p-3">
                        <h6 class="m-0">Requests</h6>
                    </div>
                    <div class="box-body p-0 ">
                        <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                            <div class="dropdown-list-image mr-3 d-flex align-items-center bg-danger justify-content-center rounded-circle text-white"
                                >DRM</div>
                            <div class="font-weight-bold mr-3">
                                <div class="text-truncate">DAILY RUNDOWN: MONDAY</div>
                                <div class="small">Nunc purus metus, aliquam vitae venenatis sit amet, porta non est.
                                </div>
                                <div class="p-2">
                                    <button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4">Accept</button>
                               
                                    <button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4"id="declined">Decline</button>
                                </div>
                            </div>
                            <span class="ml-auto mb-auto POspan">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-light btn-sm rounded" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical"></i>edit
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right" >
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-delete"></i>
                                            Delete</button>
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-close"></i> Turn
                                            Off</button>
                                    </div>
                                </div>
                                <br />
                                <div class="text-right text-muted pt-1">1d</div>
                            </span>
                        </div>

                        <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                            <div class="dropdown-list-image mr-3"><img class="rounded-circle"
                                    src="https://bootdey.com/img/Content/avatar/avatar3.png" alt="" /></div>
                            <div class="font-weight-bold mr-3">
                                <div class="text-truncate">DAILY RUNDOWN: SATURDAY</div>
                                <div class="small">Pellentesque semper ex diam, at tristique ipsum varius sed.
                                    Pellentesque non metus ullamcorper</div>

                                    <div class="p-2">
                                
                                    <button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4">Accept</button>
                                
                                    <button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4 "id="declined">Decline</button>
                                    </div>
                            </div>
                            
                            <span class="ml-auto mb-auto POspan">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-light btn-sm rounded" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false"> edit
                                        <i class="mdi mdi-dots-vertical"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-delete"></i>
                                            Delete</button>
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-close"></i> Turn
                                            Off</button>
                                    </div>
                                </div>
                                <br />
                                <div class="text-right text-muted pt-1">2d</div>
                            </span>
                        </div>
                        <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar2.png"
                                    alt="" />
                            </div>
                            <div class="font-weight-bold mr-3">
                                <div class="mb-2"><span class="font-weight-normal">Congratulate Gurdeep Singh Osahan
                                        (iamgurdeeposahan)</span> for 5 years at Askbootsrap Pvt.</div>
                                
<button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4">Accept</button>
                               
<button type="button" class="btn btn-outline-success btn-sm pl-4 pr-4" id="declined">Decline</button>
                            </div>
                            <span class="ml-auto mb-auto POspan">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-light btn-sm rounded" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">edit
                                        <i class="mdi mdi-dots-vertical"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-delete"></i>
                                            Delete</button>
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-close"></i> Turn
                                            Off</button>
                                    </div>
                                </div>
                                <br />
                                <div class="text-right text-muted pt-1">3d</div>
                            </span>
                        </div>
                        <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar4.png"
                                    alt="" />
                            </div>
                            <div class="font-weight-bold mr-3">
                                <div>
                                    <span class="font-weight-normal">Congratulate Mnadeep singh
                                        (iamgurdeeposahan)</span> for 4 years at Askbootsrap Pvt.

                                </div>
                            </div>
                            <span class="ml-auto mb-auto POspan">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-light btn-sm rounded" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">edit
                                        <i class="mdi mdi-dots-vertical"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-delete"></i>
                                            Delete</button>
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-close"></i> Turn
                                            Off</button>
                                    </div>
                                </div>
                                <br />
                                <div class="text-right text-muted pt-1">3d</div>
                            </span>
                        </div>
                        <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                            <div
                                class="dropdown-list-image mr-3 d-flex align-items-center bg-success justify-content-center rounded-circle text-white">
                                M</div>
                            <div class="font-weight-bold mr-3">
                                <div class="text-truncate">DAILY RUNDOWN: MONDAY</div>
                                <div class="small">Nunc purus metus, aliquam vitae venenatis sit amet, porta non est.
                                </div>
                            </div>
                            <span class="ml-auto mb-auto POspan">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-light btn-sm rounded" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">edit
                                        <i class="mdi mdi-dots-vertical"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-delete"></i>
                                            Delete</button>
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-close"></i> Turn
                                            Off</button>
                                    </div>
                                </div>
                                <br />
                                <div class="text-right text-muted pt-1">3d</div>
                            </span>
                        </div>

                        <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request" >
                            <div class="dropdown-list-image mr-3"><img class="rounded-circle"
                                    src="https://bootdey.com/img/Content/avatar/avatar3.png" alt="" />
                            </div>
                            <div class="font-weight-bold mr-3">
                                <div class="text-truncate">DAILY RUNDOWN: SATURDAY</div>
                                <div class="small">Pellentesque semper ex diam, at tristique ipsum varius sed.
                                    Pellentesque non metus ullamcorper</div>
                                    <div class=" small text-success "> <span id="checked">Request Declined </span></div>
                            </div>
                            <span class="ml-auto mb-auto POspan" >
                                <div class="btn-group">
                                    <button type="button" class="btn btn-light btn-sm rounded" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">edit
                                        <i class="mdi mdi-dots-vertical"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-delete"></i>
                                            Delete</button>
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-close"></i> Turn
                                            Off</button>
                                    </div>
                                </div>
                                <br />
                                <div class=" text-right text-muted pt-1" >4d</div>
                            </span>
                        </div>


                        <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar1.png"
                                    alt="" />
                            </div>
                            <div class="font-weight-bold mr-3">
                                <div class="mb-2"><span class="font-weight-normal">Congratulate Gurdeep Singh Osahan
                                        (iamgurdeeposahan)</span> for 5 years at Askbootsrap Pvt.</div>
                                        <div class="small text-success"><i class="fa fa-check-circle"></i> You sent Mandeep
                                            a message</div>
                            </div>
                            <span class="ml-auto mb-auto POspan">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-light btn-sm rounded" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">edit
                                        <i class="mdi mdi-dots-vertical"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-delete"></i>
                                            Delete</button>
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-close"></i> Turn
                                            Off</button>
                                    </div>
                                </div>
                                <br />
                                <div class="text-right text-muted pt-1">4d</div>
                            </span>
                        </div>
                        <div class="p-3 d-flex align-items-center osahan-post-header request">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar2.png"
                                    alt="" />
                            </div>
                            <div class="font-weight-bold mr-3">
                                <div>
                                    <span class="font-weight-normal">Congratulate Mnadeep singh
                                        (iamgurdeeposahan)</span> for 4 years at Askbootsrap Pvt.
                                    <div class="small text-success"><i class="fa fa-check-circle"></i> You sent Mandeep
                                        a message</div>
                                </div>
                            </div>
                            <span class="ml-auto mb-auto POspan">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-light btn-sm rounded" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">edit
                                        <i class="mdi mdi-dots-vertical"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-delete"></i>
                                            Delete</button>
                                        <button class="dropdown-item" type="button"><i class="mdi mdi-close"></i> Turn
                                            Off</button>
                                    </div>
                                </div>
                                <br />
                                <div class="text-right text-muted pt-1">5d</div>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'footer.php';?>

</body>

</html>