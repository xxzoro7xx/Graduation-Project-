<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>

<?php include 'head.php'; ?>

<body>


  <?php include 'header.php'; ?>
 

  <!--body-->
  <?php session_start(); ?>

  <div class="row login ">
    <div class="col-lg-5 col-md-10 col-sm-10 loginF shadow p-3 mb-5 bg-body rounded">

    
      <form class="px-4 py-3 "name="login" method="post"  action="database_files/log_in.php">
        <div class="mb-3">
          <label for="email" class="form-label">Email address</label>
          <input type="email" class="form-control" placeholder="email@example.com" name="email">
        </div>
        <div class="mb-3">
          <label for="password" class="form-label" >Password</label>
          <input type="password" class="form-control" name="password" placeholder="Password">
        </div>

        <div id="selectb">
        <input type="radio" id="html" name="type" value="teacher">
        <label for="html" id='mr'>Teacher</label>
        <input type="radio" id="html" name="type" value="student">
        <label for="html">Student</label>
        </div>
        <span class="error"> <?php if (isset($_SESSION['err'])){echo $_SESSION['err'];echo '<br>'; unset($_SESSION['err']);}?></span>
        <br>
        
        <button type="submit" class="btn btn-primary" >Sign in</button>
      </form>


      <div class="dropdown-divider"></div>
      <a class="dropdown-item" href="register.php">New around here? Sign up</a>
      <a class="dropdown-item" href="#">Forgot password?</a>
    </div>
  </div>


  <?php include 'footer.php'; ?>
</body>

</html>