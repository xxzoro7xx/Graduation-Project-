<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>



<?php include 'head.php'; ?>

<body>


    <?php include 'header.php'; ?>

    <img src="images/bb029b7d-694a-4e9e-85ff-97176cfab802.jfif" alt="home page" id="homepage">

    <div class="centered">
        <h1>Welcome to Education World </h1>

        <div class="blue-btn">
            <a class="first-link" href="login.php">
                Get Started
            </a>
            <a href="login.php">
                Get Started
            </a>
        </div>
    </div>


    <?php include 'footer.php'; ?>
</body>


<style>
    /* Bottom right text */

    .centered {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    .blue-btn a {
        color: white;
        text-decoration: none;
        text-align: center;
        display: block;
        /* important */
    }

    .blue-btn,
    .first-link {
        -webkit-transition: 0.3s;
        -moz-transition: 0.3s;
        -ms-transition: 0.3s;
        -o-transition: 0.3s;
        transition: 0.3s;
    }


    .blue-btn {
        height: 64px;
        font: normal normal 700 1em/4em Arial, sans-serif;
        overflow: hidden;
        width: 200px;
        background-color: #3b5998;
        border-radius: 20px;
        position: relative;
        left: 25%;
    }

    .blue-btn:hover {
        background-color: #003D60;

    }

    .blue-btn a:hover {
        text-decoration: none;
    }

    .first-link {
        margin-top: 0em;
    }

    .blue-btn:hover .first-link {
        margin-top: -4em;
    }
</style>

</html>