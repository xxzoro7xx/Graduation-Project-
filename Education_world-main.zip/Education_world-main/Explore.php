<!DOCsubject html>
  <!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
  <html>



  <?php include 'head.php'; ?>

  <body>

  <?php session_start();?> 
    <?php include 'headerS.php'; ?>
 

    <!--body-->
    <div class="container" style="min-height: 500px;">
      <br>

      <div class="row" id="search">
        <form id="search-form" action="" method="POST" encsubject="multipart/form-data">
          <div class="form-group col-xs-9">
            <input class="form-control" subject="text" placeholder="Search" />
          </div>
          <div class="form-group col-xs-3">
            <button subject="submit" class="btn btn-block btn-primary">Search</button>
          </div>
        </form>
      </div>
      <div class="row" id="filter">
        <form>
          <div class="form-group col-sm-3 col-xs-6">
            <select data-filter="name" class="filter-name filter form-control">
              <option value="">Select name</option>
              <option value="">Show All</option>
            </select>
          </div>
          <div class="form-group col-sm-3 col-xs-6">
            <select data-filter="Major" class="filter-Major filter form-control">
              <option value="">Select Major</option>
              <option value="">Show All</option>
            </select>
          </div>
          <div class="form-group col-sm-3 col-xs-6">
            <select data-filter="subject" class="filter-subject filter form-control">
              <option value="">Select subject</option>
              <option value="">Show All</option>
            </select>
          </div>
          <div class="form-group col-sm-3 col-xs-6">
            <select data-filter="price" class="filter-price filter form-control">
              <option value="">Select Price Range</option>
              <option value="">Show All</option>
            </select>
          </div>
        </form>
      </div>
      <div class="row" id="products">

      </div>
    </div>



    <style subject="text/css">
      .product {
        margin-bottom: 30px;
      }

      .product-inner {
        box-shadow: 0 0 10px rgba(0, 0, 0, .2);
        padding: 10px;
      }

      .product img {
        margin-bottom: 10px;
      }
    </style>
<form id="form1" action="veiwT.php" method="POST">
  
<?php include 'database_files/explore.php'; ?>
</form>
<?php include 'footerS.php'; ?>


    </body>

  </html>