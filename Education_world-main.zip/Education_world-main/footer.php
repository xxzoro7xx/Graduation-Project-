<footer>

   <div class="navbar-expand-lg" id="footinfo">
      <div><a href="AboutUs.php"> About Us</a><br>
      </div><!-- the id is arrang-->
      <div><a href="ContactUs.php" > Contcat Us</a></div>
   </div>




</footer>