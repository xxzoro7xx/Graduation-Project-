<?php

include('connection.php');


session_start();
$id = $_POST['state'];


    mysqli_query($con,"UPDATE porder SET state = '3'  WHERE o_id = '$id';");
    header("Location: http://localhost/education_world/request.php");

?>