<?php

include('connection.php');

session_start();

$ido = $_POST['idO'];



mysqli_query($con,"UPDATE porder SET state = '2'  WHERE o_id = '$ido';");

header("Location: http://localhost/education_world/request.php");
// session_destroy();






?>