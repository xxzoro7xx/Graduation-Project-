<?php

include('connection.php');




// <?php echo $_SESSION['email']; 
$id = $_SESSION['IDT'];

// echo "<script>alert('$id');</script>";
$sql = "select COUNT(*) from porder where T_ID = '$id'";
$info = mysqli_query($con, $sql);
$row = mysqli_fetch_array($info);
$total = $row[0];


$sql = "select * from teacher where T_ID = '$id'";
$result = mysqli_query($con, $sql);
$row2 = mysqli_fetch_array($result);
$TFName = $row2["FName"]; 
$TLName = $row2["LName"]; 


$sql = "select * from Porder where T_ID = '$id'";
$info = mysqli_query($con, $sql);

// if there is no teacher not active 
if($total == 0){
    echo <<<EOL
    <div class="p-3 d-flex align-items-center osahan-post-header request">
    <div class="dropdown-list-image mr-3"></div>
    <div class="font-weight-bold mr-3">
        <div>
            <span class="font-weight-normal">There No orders</span> 
            <div class="small text-success"><i class="fa fa-check-circle"></i> Thank you</div>
        </div>
    </div>
</div>

EOL;
}else
for (;$total >0 ; $total--){
while($row = mysqli_fetch_array($info)){
    $oid = $row["o_id"]; 
    $idS = $row['S_ID'];
    $oState = $row["state"]; 
    $des= $row['description'];
    $price = $row["price"]; 

    $sql = "select * from Student where S_ID = '$idS'";
    $result = mysqli_query($con, $sql);
    $row2 = mysqli_fetch_array($result);
    $SFName = $row2["FName"]; 
    $SLName = $row2["LName"]; 

    



if($oState == 1){
echo <<<EOL
    <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
    <div class="dropdown-list-image mr-3">
        <img class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar1.png"
            alt="" />
    </div>
    <div class="font-weight-bold mr-3">
        <div class="mb-2"><span >$TFName $TLName </span><br>
        <span class="font-weight-normal"> Your Have a Request from $SFName $SLName.<br>$des Price: $price</span></div>

        <div>
            <form action="database_teacher/approve.php" method="post" style="display: inline;">
            <button type="Submit" name='idO' value="$oid" class="btn btn-outline-success btn-sm pl-4 pr-4"id="Accept">Accept</button>
            </form>
            <form action="database_teacher/cancelO.php" method="post" style="display: inline;" >
            <button type="Submit" name='state' value="$oid" class="btn btn-outline-success btn-sm pl-4 pr-4" id="declined">Cancel</button>
            </form>
        </div>
  
         
                <div class="small text-success"><i class="fa fa-check-circle"></i> Do You want This Request</div>
                    </div>
        </div>




EOL;
}

if($oState == 2){
    echo <<<EOL
    <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
    <div class="dropdown-list-image mr-3">
        <img class="rounded-circle" src="https://bootdey.com/img/Content/avatar/avatar1.png"
            alt="" />
    </div>
    <div class="font-weight-bold mr-3">
        <div class="mb-2"><span >$TFName $TLName </span><br>
        <span class="font-weight-normal"> Wating for $TFName $TLName to Pay</span></div>

         
                <div class="small text-success"><i class="fa fa-check-circle"></i> Wating for payment</div>
                    </div>
            </div>

    
    
    
    
    EOL;
    }

    if($oState == 3){
        echo <<<EOL
                        
                         <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                            <div
                                class="dropdown-list-image mr-3 d-flex align-items-center bg-success justify-content-center rounded-circle text-white">
                                M</div>
                            <div class="font-weight-bold mr-3">
                                <div class="text-truncate">$TFName $TLName</div>
                                <div class="small">You Declined The Request of $TFName $TLName
                                <br><span id="checked">Request Declined </span>
                                </div>
                            </div>
                            </div>
                   


        
        
        
        
        EOL;
        }

        if($oState == 4){
            echo <<<EOL
                            
                             <div class="p-3 d-flex align-items-center border-bottom osahan-post-header request">
                                <div
                                    class="dropdown-list-image mr-3 d-flex align-items-center bg-success justify-content-center rounded-circle text-white">
                                    M</div>
                                <div class="font-weight-bold mr-3">
                                    <div class="text-truncate">$TFName $TLName</div>
                                    <div class="small">$TFName $TLName Will Contact You
                                    <br><div class="small text-success"><i class="fa fa-check-circle"></i> Payment completed</div>
                                    </div>
                                    </div>
                                </div>
                       
    
    
            
            
            
            
            EOL;
            }




} 

}

?>