<?php

include('./connection.php');



session_start();


$FName = $_POST['first_name'];
$LName = $_POST['last_name'];
$major = $_POST['major'];
$email = $_POST['email'];
$passwd = $_POST['user_password'];
$passwd_again = $_POST['confirm_password'];
$file = $_POST['myfile'];
$phone = $_POST['phone'];
$type = "teacher";
$a = "1";
if ($email != "" && $passwd != "" && $passwd_again != "" && $FName != "" && $LName != "" && $major != "" && $phone != "") {
    // make sure the two passwords match
    if ($passwd === $passwd_again) {
        // make sure the password meets the min strength requirements
        $query = mysqli_query($con, "SELECT * FROM $type WHERE Email='{$email}'");
        if (mysqli_num_rows($query) == 0) {
            // create and format some variables for the database
            mysqli_query($con, "INSERT INTO $type (T_ID ,Email , Password,Major, FName, LName,Documents,phone ) VALUES ('{}','{$email}', '{$passwd}', '{$major}', '{$FName}', '{$LName}','{$file}','{$phone}')");
            $_SESSION['err'] = 'Registered Successfully... Waiting for Approval';
            header("Location: http://localhost/education_world/registerTeacher.php");
        } else {
            $sql = "Select state from $type where email='$email'; ";
            $info = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($info);
            $state = $row['state'];
            if($state==3){
                $sql = "UPDATE $type set password = '$passwd',  LName = '$LName', FName = '$FName', Documents = '$file', Major = '$major', state = '$a', Phone = '$phone' where email='$email' ";
                 mysqli_query($con, $sql);
                $_SESSION['err'] = 'Updated';
                header("Location: http://localhost/education_world/registerTeacher.php");
                exit;
            }else{

                $_SESSION['err'] = 'This Email is Taken';
                header("Location: http://localhost/education_world/registerTeacher.php");
            }
        }
    } else {
        $_SESSION['err'] = 'The Passwords do not Match';
        header("Location: http://localhost/education_world/registerTeacher.php");
    }
} else {
    $_SESSION['err'] = 'Please Fill the Form';
    header("Location: http://localhost/education_world/registerTeacher.php");
}

?>