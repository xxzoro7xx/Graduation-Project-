<?php

include('connection.php');


session_start();

// <?php echo $_SESSION['email']; 

$des = $_POST['des'];  
$id = $_SESSION['IDT'];
$post = $_POST['post'];  
 
if($post == 1){
        $date = date('y-m-d H:i:s');
        if($des == ""){
                $_SESSION['err1'] = "You did not Write Anyting...";
        }else{
        mysqli_query($con, "INSERT INTO postt (Description ,date , T_ID) VALUES ('{$des}','{$date}', '{$id}')");  
        }
        
}else{
        mysqli_query($con,"UPDATE teacher SET description = '$des'  WHERE T_ID = '$id';");
}

header("Location: http://localhost/education_world/profileteacher.php");


?>