<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>



<?php include 'head.php'; ?>

<link rel="stylesheet" href="Gcss.css">



<body>


    <?php include 'headerS.php'; ?>

    <div class="bodyex">

    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div id="content" class="content content-full-width">
                    <!-- begin profile -->
                    <div class="profile">
                        <div class="profile-header">
                            <!-- BEGIN profile-header-cover -->
                            <div class="profile-header-cover"></div>
                            <!-- END profile-header-cover -->
                            <!-- BEGIN profile-header-content -->
                            <div class="profile-header-content">
                                <!-- BEGIN profile-header-img -->
                                <div class="profile-header-img">
                                    <img src="https://www.w3schools.com/w3images/avatar1.png" alt="">
                                </div>
                                <!-- END profile-header-img -->
                                <!-- BEGIN profile-header-info -->
                                <div class="profile-header-info">
                                    <h4 class="m-t-10 m-b-5">student</h4>
                                    <p class="m-b-10">UXUI</p>
                                    <a href="#" class="btn btn-sm btn-info mb-2">Edit Profile</a>
                                </div>
                                <!-- END profile-header-info -->
                            </div>
                            <!-- END profile-header-content -->
                            <!-- BEGIN profile-header-tab -->
                            <!--   <ul class="profile-header-tab nav nav-tabs">
                                <li class="nav-item"><a href="#" class="nav-link active show" data-toggle="tab">Explore</a></li>
                                <li class="nav-item"><a href="profile.php" class="nav-link">Profile</a></li>
                                <li class="nav-item"><a href="#" class="nav-link" data-toggle="tab">Notifications</a></li>
                                <li class="nav-item"><a href="#" class="nav-link" data-toggle="tab">student's review</a></li>
                                <li class="nav-item"><a href="club.php" class="nav-link" data-toggle="tab">student club</a></li>
                                <li><a href="FindingTeacher.php"> <i class="fa fa-edit"></i> search for teacher</a></li>

                            </ul>
                            END profile-header-tab -->
                        </div>
                    </div>
                    <!-- end profile -->
                    <!-- begin profile-content -->
                    <div class="profile-content">
                        <!-- begin tab-content -->
                        <div class="tab-content p-0">
                            <!-- begin #profile-post tab -->
                            <div class="tab-pane fade active show" id="profile-post">
                                <!-- begin timeline -->
                                <ul class="timeline">
                                    <li>
                                        <!-- begin timeline-time -->
                                        <div class="timeline-time">
                                            <span class="date">today</span>
                                            <span class="time">04:20</span>
                                        </div>
                                        <!-- end timeline-time -->
                                        <!-- begin timeline-icon -->
                                        <div class="timeline-icon">
                                            <a href="javascript:;">&nbsp;</a>
                                        </div>
                                        <!-- end timeline-icon -->
                                        <!-- begin timeline-body -->
                                        <div class="timeline-body"></div>
                                        <div class="timeline-header">
                                            <span class="userimage"><img src="https://www.w3schools.com/w3images/avatar2.png" alt=""></span>
                                            <span class="username"><a href="javascript:;">teacher</a> <small></small></span>
                                            <span class="pull-right text-muted">18 Views</span>
                                        </div>
                                        <div class="timeline-content">
                                            <p>
                                                I will host an online class today
                                            </p>
                                        </div>
                                        <div class="timeline-likes">
                                            <div class="stats-right">
                                                <span class="stats-text">29 Shares</span>
                                                <span class="stats-text">21 Comments</span>
                                            </div>
                                            <div class="stats">
                                                <span class="fa-stack fa-fw stats-icon">
                                                    <i class="fa fa-circle fa-stack-2x text-danger"></i>
                                                    <i class="fa fa-heart fa-stack-1x fa-inverse t-plus-1"></i>
                                                </span>
                                                <span class="fa-stack fa-fw stats-icon">
                                                    <i class="fa fa-circle fa-stack-2x text-primary"></i>
                                                    <i class="fa fa-thumbs-up fa-stack-1x fa-inverse"></i>
                                                </span>
                                                <span class="stats-total">4.3k</span>
                                            </div>
                                        </div>
                                        <div class="timeline-footer">
                                            <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-thumbs-up fa-fw fa-lg m-r-3"></i> Like</a>
                                            <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-comments fa-fw fa-lg m-r-3"></i> Comment</a>
                                            <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-share fa-fw fa-lg m-r-3"></i> Share</a>
                                        </div>
                                        <div class="timeline-comment-box">
                                            <div class="user"><img src="https://www.w3schools.com/w3images/avatar1.png"></div>
                                            <div class="input">
                                                <form action="">
                                                    <div class="input-group">
                                                        <input type="text" class="form-control rounded-corner" placeholder="Write a comment...">
                                                        <span class="input-group-btn p-l-10">
                                                            <button class="btn btn-primary f-s-12 rounded-corner" type="button">Comment</button>
                                                        </span>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                            </div>
                            <!-- end timeline-body -->
                            </li>
                            <li>
                                <!-- begin timeline-time -->
                                <div class="timeline-time">
                                    <span class="date">yesterday</span>
                                    <span class="time">20:17</span>
                                </div>
                                <!-- end timeline-time -->
                                <!-- begin timeline-icon -->
                                <div class="timeline-icon">
                                    <a href="javascript:;">&nbsp;</a>
                                </div>
                                <!-- end timeline-icon -->
                                <!-- begin timeline-body -->
                                <div class="timeline-body">
                                    <div class="timeline-header">
                                        <span class="userimage"><img src="https://bootdey.com/img/Content/avatar/avatar2.png" alt=""></span>
                                        <span class="username">teacher2</span>
                                        <span class="pull-right text-muted">82 Views</span>
                                    </div>
                                    <div class="timeline-content">
                                        <p>I can teach English</p>
                                    </div>
                                    <div class="timeline-footer">
                                        <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-thumbs-up fa-fw fa-lg m-r-3"></i> Like</a>
                                        <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-comments fa-fw fa-lg m-r-3"></i> Comment</a>
                                        <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-share fa-fw fa-lg m-r-3"></i> Share</a>
                                    </div>
                                </div>
                                <!-- end timeline-body -->
                            </li>
                            <li>
                                <!-- begin timeline-time -->
                                <div class="timeline-time">
                                    <span class="date">24 February 2022</span>
                                    <span class="time">08:17</span>
                                </div>
                                <!-- end timeline-time -->
                                <!-- begin timeline-icon -->
                                <div class="timeline-icon">
                                    <a href="javascript:;">&nbsp;</a>
                                </div>
                                <!-- end timeline-icon -->
                                <!-- begin timeline-body -->
                                <div class="timeline-body">
                                    <div class="timeline-header">
                                        <span class="userimage"><img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt=""></span>
                                        <span class="username">A</span>
                                        <span class="pull-right text-muted">1,282 Views</span>
                                    </div>
                                    <div class="timeline-content">
                                        <p class="lead">
                                            I am able to teach AI.
                                        </p>
                                    </div>
                                    <div class="timeline-footer">
                                        <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-thumbs-up fa-fw fa-lg m-r-3"></i> Like</a>
                                        <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-comments fa-fw fa-lg m-r-3"></i> Comment</a>
                                        <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-share fa-fw fa-lg m-r-3"></i> Share</a>
                                    </div>
                                </div>
                                <!-- end timeline-body -->
                            </li>
                            <li>
                                <!-- begin timeline-time -->
                                <div class="timeline-time">
                                    <span class="date">10 January 2022</span>
                                    <span class="time">20:43</span>
                                </div>
                                <!-- end timeline-time -->
                                <!-- begin timeline-icon -->
                                <div class="timeline-icon">
                                    <a href="javascript:;">&nbsp;</a>
                                </div>
                                <!-- end timeline-icon -->
                                <!-- begin timeline-body -->
                                <div class="timeline-body">
                                    <div class="timeline-header">
                                        <span class="userimage"><img src="https://bootdey.com/img/Content/avatar/avatar5.png" alt=""></span>
                                        <span class="username">B</span>
                                        <span class="pull-right text-muted">1,021,282 Views</span>
                                    </div>
                                    <div class="timeline-content">

                                        <p>looking for cs project </p>
                                        <p class="m-t-20">
                                            <img src="../assets/img/gallery/gallery-5.jpg" alt="">
                                        </p>
                                    </div>
                                    <div class="timeline-footer">
                                        <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-thumbs-up fa-fw fa-lg m-r-3"></i> Like</a>
                                        <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-comments fa-fw fa-lg m-r-3"></i> Comment</a>
                                        <a href="javascript:;" class="m-r-15 text-inverse-lighter"><i class="fa fa-share fa-fw fa-lg m-r-3"></i> Share</a>
                                    </div>
                                </div>
                                <!-- end timeline-body -->
                            </li>
                            <li>
                                <!-- begin timeline-icon -->
                                <div class="timeline-icon">
                                    <a href="javascript:;">&nbsp;</a>
                                </div>
                                <!-- end timeline-icon -->
                                <!-- begin timeline-body -->
                                <div class="timeline-body">
                                    Loading....
                                </div>
                                <!-- begin timeline-body -->
                            </li>
                            </ul>
                            <!-- end timeline -->
                        </div>
                        <!-- end #profile-post tab -->
                    </div>
                    <!-- end tab-content -->
                </div>
                <!-- end profile-content -->
            </div>
        </div>
        <!-- end tab-content -->
    </div>
    <!-- end profile-content -->
    </div>
    </div>
    </div>
    </div>





    <?php include 'footerS.php'; ?>

</body>





</html>