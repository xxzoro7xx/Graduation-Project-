<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <link rel="stylesheet" href="contact us.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php  include 'head.php';?>

<body>
<?php session_start();?>
<?php include 'header.php';?>
    <!--body-->

    <div class="container">
    <div class="content">
      <div class="left-side">
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Phone</div>
          <div class="text-one">+966XXXXXXXXX</div>
          <div class="text-two">+966XXXXXXXXX</div>
        </div>
        <div class="email details">
          <i class="fas fa-envelope"></i>
          <div class="topic">Email</div>
          <div class="text-one">Education_world@gmail.com</div>
          <div class="text-two">info.Education_world@gmail.com</div>
        </div>
      </div>
      <div class="right-side">
        <div class="topic-text">Send us a message</div>
        <p>If you have any problem or concern about our platform , you can send me message from here. It's my pleasure to help you.</p>
        <form action="admin/uplodC.php" method="post">
        <div class="input-box">
          <input type="text" required="required" placeholder="Enter your name" name="name">
        </div>
        <div class="input-box">
          <input type="email" maxlength="50" required="required" placeholder="Enter your email" name="email">
        </div>
        <div class="input-box message-box">
          <textarea maxlength="500" required="required" placeholder="Enter your message" name="des"></textarea>
        </div>
        <span class="mas"> <?php  if (isset($_SESSION['err2'])){echo $_SESSION['err2'];echo '<br>'; unset($_SESSION['err2']);}?></span>
        <br>
        <div class="button">
          <input type="submit" value="Submit" >
        </div>
      </form>
    </div>
    </div>
  </div>



</body>

</html>