    <!-- headers -->
    <nav class="edit navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="explore.php">Education World</a>
        <button class="navbar-toggler" type="button" onclick=" headerBo()">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class=" navbar-collapse " id="hItem">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="profile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="explore.php"> Explore</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="club.php">Club</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="notification.php">Notifications</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="database_files/log_out.php">Log out</a>
                </li>

                <!-- <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div> -->
                </li>
            </ul>

        </div>
    </nav>