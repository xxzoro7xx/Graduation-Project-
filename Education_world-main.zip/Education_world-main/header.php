    <!-- headers -->
    <nav class="edit navbar navbar-expand-lg navbar-light bg-light">

        <a class="navbar-brand" href="home.php">Education World</a>

        <button class="navbar-toggler" type="button" onclick="headerBo()" >
            <span class="navbar-toggler-icon" ></span>
        </button>

        <div class="navbar-collapse " id="hItem">
            <ul class="navbar-nav ">
                <li class="nav-item">
                    <a class="nav-link" href="login.php"><i class="fas fw-light fa-address-card"></i> Login</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="ContactUs.php">Contact Us <span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="AboutUs.php">About Us</a>
                </li>
                <!-- <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div> -->
                
            </ul>

        </div>
    </nav>