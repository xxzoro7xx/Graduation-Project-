<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>

<?php include 'head.php'; ?>
<link rel="stylesheet" href="Gcss.css">

<body>


  <?php include 'header.php'; ?>


  <!--body-->

  <div class="container">
    <h1 class="">Register as:

    </h1>
    <br>

    <div class="skills">
      <a class="dropdown-item" href="registerTeacher.php"><span class="active"> Teacher</span></a>
      <a class="dropdown-item" href="registerSTU.php"><span class="active">Student </span></a>
    </div>
  </div>

</html>