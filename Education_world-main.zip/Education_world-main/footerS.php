<footer>

   <div class="navbar-expand-lg" id="footinfo">
      <div><a href="AboutUsS.php"> About Us</a><br>
      </div><!-- the id is arrang-->
      <div><a href="ContactUsS.php"> Contcat Us</a></div>
   </div>




</footer>