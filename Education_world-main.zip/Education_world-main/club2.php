<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>



<?php include 'head.php'; ?>

<body>


  <?php include 'headerS.php'; ?>


  <!--body-->

  <div class="Cbody">
    <div class="content">
      <div class="containerC">
        <!-- end row -->
        <div class="row">
          <div class="col-lg-4">
            <div class="text-center card-box">
              <div class="member-card pt-2 pb-2">
                <div class="thumb-lg member-thumb mx-auto"><img src="" class="rounded-circle img-thumbnail" alt="profile-image"></div>
                <div class="">
                  <h4 class="ch4"> Architecture</h4>
                  <p class="text-muted">Architecture club that help student </p>
                </div>
                <form method="post" action="database_files/JoinC.php">
                <button name="the_name" type="submit" value="7" class="btn btn-primary mt-3 btn-rounded waves-effect w-md waves-light">Join Now</button>
                
                <div class="mt-4">
                  <div class="row">
                    <div class="col-4">
                      <div class="mt-3">
                        <h4 class="ch4">0</h4>
                        <p class="mb-0 text-muted">Members</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- end col -->
          <div class="col-lg-4">
            <div class="text-center card-box">
              <div class="member-card pt-2 pb-2">
                <div class="thumb-lg member-thumb mx-auto"><img src="" class="rounded-circle img-thumbnail" alt="profile-image"></div>
                <div class="">
                  <h4 class="ch4">Health Science Club</h4>
                  <p class="text-muted">Health Science club that help student </p>
                </div>

                <button name="the_name" type="submit" value="8" class="btn btn-primary mt-3 btn-rounded waves-effect w-md waves-light">Join Now</button>
               
                 <div class="mt-4">
                  <div class="row">
                    <div class="col-4">
                      <div class="mt-3">
                        <h4 class="ch4">0</h4>
                        <p class="mb-0 text-muted">Members </p>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- end col -->
          <div class="col-lg-4">
            <div class="text-center card-box">
              <div class="member-card pt-2 pb-2">
                <div class="thumb-lg member-thumb mx-auto"><img src="" class="rounded-circle img-thumbnail" alt="profile-image"></div>
                <div class="">
                  <h4 class="ch4">Social Sciences & Law club</h4>
                  <p class="text-muted"> club descrption </p>
                </div>

                <button name="the_name" type="submit" value="9" class="btn btn-primary mt-3 btn-rounded waves-effect w-md waves-light">Join Now</button>
               
                 <div class="mt-4">
                  <div class="row">
                    <div class="col-4">
                      <div class="mt-3">
                        <h4 class="ch4">0</h4>
                        <p class="mb-0 text-muted"> member</p>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- end col -->
        </div>

 
        <!-- end row -->

        <!-- end row -->
        <div class="row">
          <div class="col-12">
            <div class="text-right">
              <ul class="pagination pagination-split mt-0 float-right">
                <li class="page-item"><a class="page-link" href="club.php" aria-label="Previous"><span aria-hidden="true">«</span> <span class="sr-only">Previous</span></a></li>
                <li class="page-item "><a class="page-link" href="club.php">1</a></li>
                <li class="page-item active"><a class="page-link" href="club2.php">2</a></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- end row -->
      </div>
      <!-- container -->
    </div>
  </div>

  </form>

<?php include 'footerS.php'; ?>
</body>

</html>