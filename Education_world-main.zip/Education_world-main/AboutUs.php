<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>



 <?php include 'head.php'; ?>

<body>

    <?php include 'header.php'; ?>



    <div class="abtBody">


        <div class="inner-container">
            <h1>About Us</h1>
            <p class="text">
                Educat World is a new website that helps students get higher grades through a variety of online services.
            </p>
            <div class="skills">
                <span class="active">Private Teacher</span>
                <span class="active">Student Club</span>
            </div>
        </div>
    </div>


</body>

</html>