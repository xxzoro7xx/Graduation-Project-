<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>

<?php include 'head.php'; ?>

<body>

  <?php include 'headeradmin.php'; ?>
 

  <!--body-->
  <br>
  <div class="card-body" >

  <?php include 'admin/complain.php'; ?>


    <!-- <div class="container shadow">
      <h6 class="preview-subject">Ali</h6>
      <p class="text-muted">I have problem with log in</p>
      <span class="text-muted text-small time-right">4 Hours Ago</span>
    </div>

    <div class="container darker shadow">
      <h6 class="preview-subject">test</h6>
      <p class="text-muted">problem desc</p>
      <span class="text-muted text-small time-right">5 Hours Ago</span>

    </div>

    <div class="container shadow">
      <h6 class="preview-subject">teacher</h6>
      <p class="text-muted">fix my problem pls</p>
      <span class="text-muted text-small time-right">10 Hours Ago</span>

    </div>

    <div class="container darker shadow">
      <p class="preview-subject">studnt</p>
      <p class="text-muted">neep help with log in </p>
      <span class="text-muted text-small time-right">1 Day Ago</span>

    </div> -->

  </div>



</body>


<style>
  .card-body{
    margin-left: 10%;
    margin-right: 12%;
    background-color: white;
    border-radius: 10px;
  }
  /* Chat containers */
  .container {
    border: 2px solid #dedede;
    background-color: #f1f1f1;
    border-radius: 5px;
    padding: 10px;
    margin: 10px 0;
  }

  /* Darker chat container */
  .darker {
    border-color: #ccc;
    background-color: #ddd;
  }

  /* Clear floats */
  .container::after {
    content: "";
    clear: both;
    display: table;
  }

  /* Style images */
  .container img {
    float: left;
    max-width: 60px;
    width: 100%;
    margin-right: 20px;
    border-radius: 50%;
  }

  /* Style the right image */
  .container img.right {
    float: right;
    margin-left: 20px;
    margin-right: 0;
  }

  /* Style time text */
  .time-right {
    float: right;
    color: #aaa;
  }

  /* Style time text */
  .time-left {
    float: left;
    color: #999;
  }
</style>

</html>